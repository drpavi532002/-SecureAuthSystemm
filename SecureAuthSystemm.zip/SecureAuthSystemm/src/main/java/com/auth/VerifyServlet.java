package com.auth;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/verify")
public class VerifyServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
                          throws ServletException, IOException {

        String email = request.getParameter("email");
        String otp = request.getParameter("otp");

        try {

            Connection con = DBConnection.getConnection();

            PreparedStatement ps = con.prepareStatement(
            "select * from users where email=? and otp=?");

            ps.setString(1, email);
            ps.setString(2, otp);

            ResultSet rs = ps.executeQuery();

            if(rs.next()) {

                PreparedStatement ps2 = con.prepareStatement(
                "update users set verified=true where email=?");

                ps2.setString(1, email);

                ps2.executeUpdate();

                response.sendRedirect("login.jsp");

            } else {

                response.getWriter().println("Invalid OTP");
            }

        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}