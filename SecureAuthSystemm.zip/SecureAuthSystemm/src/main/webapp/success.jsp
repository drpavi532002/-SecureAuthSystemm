<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Success</title>
</head>
<body>

<h1>Login Successful 😄🔥</h1>

</body>
</html>