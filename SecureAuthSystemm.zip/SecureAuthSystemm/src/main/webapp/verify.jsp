<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Verify OTP</title>
</head>
<body>

<h2>OTP Verification</h2>

<form action="verify" method="post">

Email:
<input type="email" name="email"><br><br>

OTP:
<input type="text" name="otp"><br><br>

<input type="submit" value="Verify">

</form>

</body>
</html>